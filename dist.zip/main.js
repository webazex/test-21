__webpack_require__.r(__webpack_exports__);
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
var form = document.getElementById('form');
var username = document.getElementById('username');
var email = document.getElementById('email');
var password = document.getElementById('password');
var phone = document.getElementById('phone');

//Show input error messages
function showError(input, message) {
    var formControl = input.parentElement;
    formControl.className = 'form-control error';
    var small = formControl.querySelector('small');
    small.innerText = message;
}

//show success colour
function showSucces(input) {
    var formControl = input.parentElement;
    formControl.className = 'form-control success';
}

//check email is valid
function checkEmail(input) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (re.test(input.value.trim())) {
        showSucces(input);
    } else {
        showError(input, 'The field cannot be empty');
    }
}

//checkRequired fields
function checkRequired(inputArr) {
    inputArr.forEach(function (input) {
        if (input.value.trim() === '') {
            showError(input, "".concat(getFieldName(input), " is required"));
        } else {
            showSucces(input);
        }
    });
}

//check input Length
function checkLength(input, min, max) {
    if (input.value.length < min) {
        showError(input, "The field cannot be empty");
    } else if (input.value.length > max) {
        showError(input, "passwords do not match");
    } else {
        showSucces(input);
    }
}

//get FieldName
function getFieldName(input) {
    return input.id.charAt(0).toUpperCase() + input.id.slice(1);
}

// check passwords match
function checkPasswordMatch(input1, input2) {
    if (input1.value !== input2.value) {
        showError(input2, 'Passwords do not match');
    }
}
function sendForm(inputArr, city) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/sender/send.php', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                console.log('Form submitted successfully');
                console.log(xhr.responseText); // Ответ сервера
            } else {
                console.error('Form submission failed');
                console.error(xhr.statusText); // Текст ошибки
            }
        }
    };
    var formData = {
        username: inputArr[0].value,
        email: inputArr[1].value,
        password: inputArr[2].value,
        phone: inputArr[3].value,
        city: city
    };

    var jsonData = JSON.stringify(formData);

    xhr.send(jsonData);
}
form.addEventListener('submit', function (e) {
    e.preventDefault();
    checkRequired([username, email, password, phone]);
    checkLength(username, 3, 15);
    checkLength(password, 6, 25);
    checkEmail(email);
    checkPasswordMatch(password);
    var cityInput = document.getElementById('city');
    if (document.querySelectorAll('.form-control.error').length === 0) {
        var cityValue = cityInput.value; // Получение значения скрытого поля "city"
        sendForm([username, email, password, phone], cityValue);
    }
});
var btnShowPassword = document.getElementById('show');
btnShowPassword.addEventListener('click', function (e) {
    e.preventDefault();
    show();
});
var inputPassword = document.getElementById('password');
var icon = document.getElementById('i');
function show() {
    if (inputPassword.getAttribute('type') == 'password') {
        inputPassword.removeAttribute('type');
        inputPassword.setAttribute('type', 'text');
        btnShowPassword.innerHTML = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\">\n    <path d=\"M10.8214 14.3813L14.8692 10.2854L14.9278 10.5375C15.7207 13.3523 13.1333 15.1204 11.1275 14.4886L10.8214 14.3813Z\" fill=\"#2A3B53\"/>\n    <path d=\"M12.0082 16.0731C14.6604 16.0731 16.5821 13.8944 16.5821 11.5281C16.5821 10.6145 16.2411 9.74351 16.0249 9.20826L18.8 6.57518C20.4163 7.70033 22.1861 9.64622 23 11.4509C21.077 15.2284 16.877 18.8225 11.6883 18.8225C10.343 18.8225 8.74602 18.388 7.4391 17.7903L9.69514 15.4893C10.415 15.8923 11.3884 16.0731 12.0082 16.0731ZM1.98183 18.7921L4.17274 16.6321L4.73227 16.0731C3.14674 14.851 1.8217 13.3994 1 11.5035C2.95828 7.42937 6.78647 4.31131 11.5912 3.96064C13.2328 3.96064 14.4313 4.14259 16.0249 4.78851L16.4333 4.4508L19.0143 2L20.2395 3.20314L3.20701 20L1.98183 18.7921ZM7.77053 13.1329L8.93487 11.9686C8.89162 11.7649 8.88721 11.5244 8.88721 11.3112C8.97453 9.72968 10.2384 8.37081 12.0817 8.37081C12.298 8.37081 12.5046 8.39923 12.7064 8.44186L13.9058 7.31413C13.2668 7.0015 12.4673 6.82981 11.5912 6.91728C9.12525 7.31413 7.62539 8.82095 7.41183 11.3906C7.41183 12.1641 7.5543 12.4852 7.77053 13.1329Z\" fill=\"#2A3B53\"/>\n    </svg>";
    } else {
        inputPassword.removeAttribute('type');
        inputPassword.setAttribute('type', 'password');
        btnShowPassword.innerHTML = "              <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 22 15\" fill=\"none\">\n    <path d=\"M21.9065 7.11753C19.6621 3.15003 15.4814 0 11 0C6.51859 0 2.33789 3.15003 0.0935156 7.11753C-0.0311719 7.35003 -0.0311719 7.63503 0.0935156 7.86753C2.33789 11.8425 6.51859 15 11 15C15.4814 15 19.6621 11.8425 21.9065 7.86753C22.0312 7.63503 22.0312 7.35003 21.9065 7.11753ZM11 12.1875C8.46958 12.1875 6.4159 10.0875 6.4159 7.50003C6.4159 4.91253 8.46958 2.81253 11 2.81253C13.5304 2.81253 15.5841 4.91253 15.5841 7.50003C15.5841 10.0875 13.5304 12.1875 11 12.1875Z\" fill=\"#2A3B53\"/>\n    <path d=\"M11 10.6869C12.7216 10.6869 14.1172 9.2598 14.1172 7.49939C14.1172 5.73898 12.7216 4.31189 11 4.31189C9.27842 4.31189 7.88281 5.73898 7.88281 7.49939C7.88281 9.2598 9.27842 10.6869 11 10.6869Z\" fill=\"#2A3B53\"/>\n    </svg>";
    }
}

//========================================================================================================================================================
// CUSTOM DROPDOWN
var selectedAll = document.querySelectorAll('.wrapper-dropdown');
selectedAll.forEach(function (selected) {
    var optionsContainer = selected.children[2];
    var optionsList = selected.querySelectorAll('div.wrapper-dropdown li');
    selected.addEventListener('click', function () {
        var arrow = selected.children[1];
        if (selected.classList.contains('active')) {
            handleDropdown(selected, arrow, false);
        } else {
            var currentActive = document.querySelector('.wrapper-dropdown.active');
            if (currentActive) {
                var anotherArrow = currentActive.children[1];
                handleDropdown(currentActive, anotherArrow, false);
            }
            handleDropdown(selected, arrow, true);
        }
    });

    // update the display of the dropdown
    var _iterator = _createForOfIteratorHelper(optionsList),
        _step;
    try {
        var _loop = function _loop() {
            var o = _step.value;
            o.addEventListener('click', function () {
                selected.querySelector('.selected-display').innerHTML = o.innerHTML;
            });
        };
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
            _loop();
        }
    } catch (err) {
        _iterator.e(err);
    } finally {
        _iterator.f();
    }
});

// check if anything else ofther than the dropdown is clicked
window.addEventListener('click', function (e) {
    if (e.target.closest('.wrapper-dropdown') === null) {
        closeAllDropdowns();
    }
});

// close all the dropdowns
function closeAllDropdowns() {
    var selectedAll = document.querySelectorAll('.wrapper-dropdown');
    selectedAll.forEach(function (selected) {
        var optionsContainer = selected.children[2];
        var arrow = selected.children[1];
        handleDropdown(selected, arrow, false);
    });
}

// open all the dropdowns
function handleDropdown(dropdown, arrow, open) {
    if (open) {
        arrow.classList.add('rotated');
        dropdown.classList.add('active');
    } else {
        arrow.classList.remove('rotated');
        dropdown.classList.remove('active');
    }
}
window.addEventListener('click', function (e){
    console.log(e.target);
});
//# sourceURL=webpack://gulp-2022/./src/js/app.js?